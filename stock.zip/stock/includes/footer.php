</div> <!-- container -->
	

	<!-- file input -->
	<script src="assests/plugins/fileinput/js/plugins/canvas-to-blob.min.js'); ?>" type="text/javascript"></script>	
	<script src="assests/plugins/fileinput/js/plugins/sortable.min.js" type="text/javascript"></script>	
	<script src="assests/plugins/fileinput/js/plugins/purify.min.js" type="text/javascript"></script>
	<script src="assests/plugins/fileinput/js/fileinput.min.js"></script>	


	<!-- DataTables -->
	<script src="assests/plugins/datatables/jquery.dataTables.min.js"></script>
	<!-- ethiopian -->
  <script src="Scripts/etcal/jquery.plugin.min.js"></script>
    <script src="Scripts/etcal/.calendars.min.js"></script>
    <script src="Scripts/etcal/jquery.calendars.plus.min.js"></script>
    <script src="Scripts/etcal/jquery.calendars.picker.min.js"></script>
    <script src="Scripts/etcal/jquery.calendars.ethiopian.min.js"></script>
    <script src="Scripts/etcal/jquery.calendars.ethiopian-am.js"></script>
 

</body>
</html>