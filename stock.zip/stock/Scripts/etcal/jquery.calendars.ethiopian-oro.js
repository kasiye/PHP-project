/* http://keith-wood.name/calendars.html
   Amharic localisation for Ethiopian calendar for jQuery v2.0.0.
   Written by Tewodros Zena February 2010. */
(function($) {
	$.calendars.calendars.ethiopian.prototype.regionalOptions['or'] = {
		name: 'Dhahata Waggaa Itiyoopjiya',
		epochs: ['BEE', 'EE'],
		monthNames: ['Fulbaana', 'Onkoololleessa', 'Saadaasa', 'Muddee', 'Amajjii', 'Gurraandhala',
			'Bitootessaa', 'Elbaa', 'Caamsaa', 'Waxabajjii', 'Adoolessaa', 'Haagayya', 'Qaammee'],
		monthNamesShort: ['Ful', 'Onk', 'Saad', 'Mud', 'Ama', 'Gur',
			'Bit', 'Elb', 'Caam', 'Wax', 'Ado', 'Haag', 'Qaam'],
		dayNames: ['Sanbata Guddaa', 'Wixaata', 'Lammaffo', 'Roobii', 'Qidame', 'Jimaata', 'Sanbata Xiqqaa'],
		dayNamesShort: ['Sab-Gud', 'Wix', 'Lam', 'Roo', 'Kam', 'Jim', 'Qid'],
		dayNamesMin: ['Sab', 'Wix', 'Lam', 'Roo', 'Kam', 'Jim', 'Qid'],
		dateFormat: 'mm/dd/yyyy',
		firstDay: 0,
		isRTL: false
	};
})(jQuery);
